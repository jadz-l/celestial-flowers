
Jonah's Notes & Last Actions

	1. The blog.html is a future feature, currently disabled.
	2. I removed the .header class sa Home and About pages at the last minute kay di na nuon ka-scroll tunogd ato.
	3. Changed all absolute paths to relative paths nga mubasag internal files, all good.
	4. Changed the file names to lower case.
	5. I corrected some margin, padding, and cleaned the code.

